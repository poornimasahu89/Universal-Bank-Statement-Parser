/**
 * Universal Bank Parser
 * FRONTEND DEMO API
 *
 * This version works WITHOUT a backend.
 * It keeps the frontend fully testable while the backend is unavailable.
 */

const TOKEN_KEY = 'ubp_token';
const USER_KEY = 'ubp_user';

/* =========================================================
   DEMO MODE
========================================================= */

const IS_DEMO_MODE = true;

export const setDemoMode = () => {};
export const isDemoModeActive = () => IS_DEMO_MODE;

/* =========================================================
   API CONFIG
========================================================= */

let API_BASE_URL =
  import.meta.env.VITE_API_BASE_URL ||
  'http://localhost:5000';

export const setApiBaseUrl = (url) => {
  if (url) {
    API_BASE_URL = url.replace(/\/+$/, '');
  }
};

export const getApiBaseUrl = () => API_BASE_URL;

/* =========================================================
   AUTH TOKEN
========================================================= */

export const setAuthToken = (token) => {
  if (token) {
    localStorage.setItem(TOKEN_KEY, token);
  } else {
    localStorage.removeItem(TOKEN_KEY);
  }
};

export const getAuthToken = () => {
  return localStorage.getItem(TOKEN_KEY);
};

export const clearAuthToken = () => {
  localStorage.removeItem(TOKEN_KEY);
  localStorage.removeItem(USER_KEY);
};

const getStoredUser = () => {
  try {
    const user = localStorage.getItem(USER_KEY);
    return user ? JSON.parse(user) : null;
  } catch {
    return null;
  }
};

/* =========================================================
   REGISTER
========================================================= */

export const registerApi = async (
  name,
  email,
  password
) => {
  if (!name || !email || !password) {
    throw new Error(
      'Name, email and password are required.'
    );
  }

  const normalizedEmail =
    email.trim().toLowerCase();

  /*
   * Demo account already exists.
   * This prevents the confusing "already exists" loop.
   */
  const existingUser = getStoredUser();

  if (
    existingUser &&
    existingUser.email === normalizedEmail
  ) {
    throw new Error(
      'User already exists with this email. Please sign in.'
    );
  }

  const user = {
    id: `demo-${Date.now()}`,
    name: name.trim(),
    email: normalizedEmail,
  };

  /*
   * Demo password is stored only for frontend testing.
   * This is NOT production authentication.
   */
  localStorage.setItem(
    'ubp_demo_password',
    password
  );

  localStorage.setItem(
    USER_KEY,
    JSON.stringify(user)
  );

  const token =
    `demo-token-${Date.now()}`;

  setAuthToken(token);

  return {
    success: true,
    token,
    user,
  };
};

/* =========================================================
   LOGIN
========================================================= */

export const loginApi = async (
  email,
  password
) => {
  if (!email || !password) {
    throw new Error(
      'Email and password are required.'
    );
  }

  const normalizedEmail =
    email.trim().toLowerCase();

  const storedUser =
    getStoredUser();

  const storedPassword =
    localStorage.getItem(
      'ubp_demo_password'
    );

  /*
   * If no demo account exists,
   * create one automatically.
   *
   * This lets you enter the application
   * immediately for frontend testing.
   */
  if (!storedUser) {

    const user = {
      id: `demo-${Date.now()}`,
      name:
        normalizedEmail
          .split('@')[0]
          .replace(/[._-]/g, ' '),
      email: normalizedEmail,
    };

    localStorage.setItem(
      USER_KEY,
      JSON.stringify(user)
    );

    localStorage.setItem(
      'ubp_demo_password',
      password
    );

    const token =
      `demo-token-${Date.now()}`;

    setAuthToken(token);

    return {
      success: true,
      token,
      user,
    };
  }

  /*
   * Check demo credentials.
   */
  if (
    storedUser.email !== normalizedEmail
  ) {
    throw new Error(
      'No demo account found for this email.'
    );
  }

  if (
    storedPassword &&
    storedPassword !== password
  ) {
    throw new Error(
      'Invalid password.'
    );
  }

  const token =
    getAuthToken() ||
    `demo-token-${Date.now()}`;

  setAuthToken(token);

  return {
    success: true,
    token,
    user: storedUser,
  };
};

/* =========================================================
   LOGOUT
========================================================= */

export const logoutApi = () => {
  clearAuthToken();
};

/* =========================================================
   UPLOAD BANK STATEMENT
========================================================= */

export const uploadBankStatementApi = async (
  file,
  bankName = 'sbi_auto'
) => {

  if (!file) {
    throw new Error(
      'No file selected.'
    );
  }

  /*
   * Demo extraction.
   */
  await delay(1000);

  return {
    success: true,

    bankDetected:
      bankName === 'sbi_auto'
        ? 'State Bank of India'
        : bankName,

    documentType:
      getDocumentType(file),

    transactions:
      getMockSbiTransactions(),

    downloadUrl: null,

    message:
      'Demo extraction completed successfully.',
  };
};

/* =========================================================
   GOOGLE SHEETS EXPORT
========================================================= */

export const exportToGoogleSheetsApi = async (
  verifiedTransactions,
  spreadsheetId = null,
  sheetName = 'Bank_Transactions'
) => {

  if (
    !Array.isArray(
      verifiedTransactions
    )
  ) {
    throw new Error(
      'Invalid transaction data.'
    );
  }

  if (
    verifiedTransactions.length === 0
  ) {
    throw new Error(
      'There are no transactions to export.'
    );
  }

  await delay(800);

  /*
   * Demo export.
   */
  return {
    success: true,
    spreadsheetId,
    sheetName,
    rowsExported:
      verifiedTransactions.length,
    timestamp:
      new Date().toISOString(),
    fileName:
      'verified_bank_statement.csv',
  };
};

/* =========================================================
   BACKEND HEALTH
========================================================= */

export const checkBackendHealthApi =
  async () => {

    try {

      const controller =
        new AbortController();

      const timeoutId =
        setTimeout(
          () => controller.abort(),
          2500
        );

      const response =
        await fetch(
          `${API_BASE_URL}/api/health`,
          {
            signal:
              controller.signal,
          }
        );

      clearTimeout(
        timeoutId
      );

      const data =
        await response
          .json()
          .catch(() => ({}));

      return {
        connected:
          response.ok,
        serverData:
          data,
      };

    } catch (error) {

      return {
        connected: false,
        error:
          error?.message ||
          'Backend unavailable',
      };

    }
  };

/* =========================================================
   BANKS
========================================================= */

export const getBanksApi =
  async () => {

    return {
      success: true,

      banks: [
        {
          id: 'sbi',
          name: 'State Bank of India',
        },
        {
          id: 'hdfc',
          name: 'HDFC Bank',
        },
        {
          id: 'icici',
          name: 'ICICI Bank',
        },
        {
          id: 'axis',
          name: 'Axis Bank',
        },
      ],
    };
  };

/* =========================================================
   HELPERS
========================================================= */

const delay = (
  milliseconds
) => {
  return new Promise(
    (resolve) =>
      setTimeout(
        resolve,
        milliseconds
      )
  );
};

const getDocumentType = (
  file
) => {

  if (!file?.type) {
    return 'Bank Statement';
  }

  if (
    file.type ===
    'application/pdf'
  ) {
    return 'PDF Document';
  }

  if (
    file.type.startsWith(
      'image/'
    )
  ) {
    return 'Scanned Image';
  }

  return 'Bank Statement';
};

/* =========================================================
   DEMO TRANSACTIONS
========================================================= */

export const getMockSbiTransactions =
  () => [

    {
      id: 'tx-101',

      lineNo: 1,

      date: '2026-07-01',

      description:
        'NEFT CREDIT — JULY SALARY',

      prevBalance:
        150000,

      debit:
        0,

      credit:
        85000,

      currBalance:
        235000,
    },

    {
      id: 'tx-102',

      lineNo: 2,

      date: '2026-07-03',

      description:
        'ATM CASH WITHDRAWAL',

      prevBalance:
        235000,

      debit:
        10000,

      credit:
        0,

      currBalance:
        225000,
    },

    {
      id: 'tx-103',

      lineNo: 3,

      date: '2026-07-05',

      description:
        'UPI PAYMENT — VENDOR SUPPLIES PVT LTD',

      prevBalance:
        225000,

      debit:
        45250,

      credit:
        0,

      /*
       * Intentional math error.
       *
       * Correct:
       * 225000 - 45250 = 179750
       */
      currBalance:
        184750,
    },

    {
      id: 'tx-104',

      lineNo: 4,

      date: '2026-07-08',

      description:
        'CHEQUE PAYMENT — VENDOR INVOICE #948210',

      prevBalance:
        179750,

      debit:
        20000,

      credit:
        0,

      currBalance:
        159750,
    },

    {
      id: 'tx-105',

      lineNo: 5,

      date: '2026-07-11',

      description:
        'RTGS INWARD — DIVIDEND RECEIVED',

      prevBalance:
        159750,

      debit:
        0,

      credit:
        32400,

      /*
       * Intentional math error.
       *
       * Correct:
       * 159750 + 32400 = 192150
       */
      currBalance:
        195000,
    },

    {
      id: 'tx-106',

      lineNo: 6,

      date: '2026-07-14',

      description:
        'BILL PAYMENT — ELECTRICITY CHARGES',

      prevBalance:
        192150,

      debit:
        4150,

      credit:
        0,

      currBalance:
        188000,
    },

  ];
