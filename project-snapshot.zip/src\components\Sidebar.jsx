import React from 'react';
import {
  LayoutDashboard,
  FileSpreadsheet,
  HelpCircle,
  ShieldCheck,
  Users,
  Settings
} from 'lucide-react';

export const Sidebar = ({
  activeTab,
  setActiveTab,
  currentUser
}) => {

  const isAdmin = true;

  const navButton = (tab) => ({
    width: '100%',
    display: 'flex',
    alignItems: 'center',
    gap: '12px',
    padding: '10px 12px',
    marginBottom: '4px',
    borderRadius: '8px',
    border: 'none',
    cursor: 'pointer',
    fontSize: '12px',
    fontWeight: 600,
    textAlign: 'left',
    background: activeTab === tab ? '#581c87' : 'transparent',
    color: activeTab === tab ? '#ffffff' : '#334155'
  });

  return (
    <aside
      style={{
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'space-between',
        width: '256px',
        minWidth: '256px',
        height: 'calc(100vh - 80px)',
        background: '#ffffff',
        borderRight: '1px solid #e2e8f0',
        flexShrink: 0,
        zIndex: 100,
        position: 'relative'
      }}
    >

      {/* TOP */}
      <div style={{ padding: '16px' }}>

        <div
          style={{
            fontSize: '11px',
            fontWeight: 700,
            letterSpacing: '1px',
            color: '#94a3b8',
            marginBottom: '8px'
          }}
        >
          MAIN
        </div>

        {/* PARSER */}
        <button
          type="button"
          style={navButton('parser')}
          onClick={() => setActiveTab('parser')}
        >
          <FileSpreadsheet size={18} />

          <span>
            AI Statement Parser
          </span>
        </button>


        {/* CORPORATE */}
        <button
          type="button"
          style={navButton('corporate')}
          onClick={() => setActiveTab('corporate')}
        >
          <LayoutDashboard size={18} />

          <span>
            Corporate Overview
          </span>
        </button>


        {/* ADMIN */}
        {isAdmin && (
          <div style={{ marginTop: '28px' }}>

            <div
              style={{
                fontSize: '11px',
                fontWeight: 700,
                letterSpacing: '1px',
                color: '#94a3b8',
                marginBottom: '8px'
              }}
            >
              ADMINISTRATION
            </div>


            {/* ADMIN PANEL */}
            <button
              type="button"
              style={{
                ...navButton('admin'),
                background:
                  activeTab === 'admin'
                    ? '#0f172a'
                    : '#f8fafc'
              }}
              onClick={() => {
                console.log('ADMIN CLICK');
                setActiveTab('admin');
              }}
            >
              <ShieldCheck size={18} />

              <span>
                Admin Panel
              </span>
            </button>


            {/* USERS */}
            <button
              type="button"
              style={{
                ...navButton('admin-users'),
                background:
                  activeTab === 'admin-users'
                    ? '#0f172a'
                    : '#f8fafc'
              }}
              onClick={() => {
                console.log('USERS CLICK');
                setActiveTab('admin-users');
              }}
            >
              <Users size={18} />

              <span>
                User Management
              </span>
            </button>


            {/* SETTINGS */}
            <button
              type="button"
              style={{
                ...navButton('admin-settings'),
                background:
                  activeTab === 'admin-settings'
                    ? '#0f172a'
                    : '#f8fafc'
              }}
              onClick={() => {
                console.log('SETTINGS CLICK');
                setActiveTab('admin-settings');
              }}
            >
              <Settings size={18} />

              <span>
                System Settings
              </span>
            </button>

          </div>
        )}

      </div>


      {/* SUPPORT */}
      <div
        style={{
          padding: '12px',
          borderTop: '1px solid #e2e8f0'
        }}
      >
        <div
          style={{
            padding: '12px',
            borderRadius: '8px',
            background: '#faf5ff',
            border: '1px solid #f3e8ff',
            fontSize: '11px',
            color: '#581c87'
          }}
        >
          <div
            style={{
              fontWeight: 700,
              display: 'flex',
              alignItems: 'center',
              gap: '6px',
              marginBottom: '5px'
            }}
          >
            <HelpCircle size={14} />

            Need Help?
          </div>

          <div style={{ color: '#475569' }}>
            Contact Universal Bank Parser Support
          </div>

          <strong>
            support@ubparser.ai
          </strong>
        </div>
      </div>

    </aside>
  );
};

export default Sidebar;