import React, { useEffect, useState } from 'react';

import { Header } from './components/Header';
import { Sidebar } from './components/Sidebar';
import { Auth } from './components/Auth';
import { AdminPanel } from './components/AdminPanel';
import { FileUpload } from './components/FileUpload';
import { DocumentViewer } from './components/DocumentViewer';
import { TransactionGrid } from './components/TransactionGrid';
import { GoogleSheetsModal } from './components/GoogleSheetsModal';
import { ApiModal } from './components/ApiModal';
import { CorporateOverview } from './components/CorporateOverview';

import {
  validateAllTransactions
} from './services/mathValidator';

import {
  uploadBankStatementApi,
  getMockSbiTransactions,
  getAuthToken,
  clearAuthToken
} from './services/api';

import {
  formatRupee,
  parseRupeeNumber
} from './utils/currencyFormatter';

import {
  FileSpreadsheet,
  AlertTriangle,
  CheckCircle2,
  LogOut
} from 'lucide-react';

import './App.css';


export function App() {

  // =========================================================
  // AUTHENTICATION
  // =========================================================

  const [isAuthenticated, setIsAuthenticated] = useState(
    Boolean(getAuthToken())
  );

  const [currentUser, setCurrentUser] = useState(null);


  // =========================================================
  // APPLICATION STATE
  // =========================================================

  const [activeTab, setActiveTab] = useState('parser');

  const [selectedBank, setSelectedBank] = useState('sbi_auto');

  const [currentFile, setCurrentFile] = useState(null);

  const [isProcessing, setIsProcessing] = useState(false);

  const [rawTransactions, setRawTransactions] = useState(
    getMockSbiTransactions()
  );

  const [validationResult, setValidationResult] = useState({
    validatedRows: [],
    hasErrors: true,
    totalErrors: 0,
    totalDebit: 0,
    totalCredit: 0,
    isFullyVerified: false
  });


  // =========================================================
  // MODALS
  // =========================================================

  const [isSheetsModalOpen, setIsSheetsModalOpen] = useState(false);

  const [isApiModalOpen, setIsApiModalOpen] = useState(false);


  // =========================================================
  // LOGIN SUCCESS
  // =========================================================

  const handleAuthSuccess = (user) => {

    console.log(
      '[APP] Authentication successful:',
      user
    );

    setCurrentUser(user || null);

    setIsAuthenticated(true);

    setActiveTab('parser');

  };


  // =========================================================
  // LOGOUT
  // =========================================================

  const handleLogout = () => {

    clearAuthToken();

    setCurrentUser(null);

    setIsAuthenticated(false);

    setCurrentFile(null);

    setRawTransactions(
      getMockSbiTransactions()
    );

    setActiveTab('parser');

  };


  // =========================================================
  // VALIDATE TRANSACTIONS
  // =========================================================

  useEffect(() => {

    const result =
      validateAllTransactions(
        rawTransactions
      );

    setValidationResult(result);

  }, [rawTransactions]);


  // =========================================================
  // UPLOAD PDF
  // =========================================================

  const handleFileUpload = async (file) => {

    setCurrentFile(file);

    setIsProcessing(true);

    try {

      const response =
        await uploadBankStatementApi(
          file,
          selectedBank
        );

      if (response?.transactions) {

        setRawTransactions(
          response.transactions
        );

      }

    } catch (error) {

      console.error(
        '[APP] Upload Error:',
        error
      );

      alert(
        `Upload Error: ${error.message}`
      );

    } finally {

      setIsProcessing(false);

    }

  };


  // =========================================================
  // SAMPLE DATA
  // =========================================================

  const handleLoadSample = (type) => {

    if (type === 'sample1') {

      setCurrentFile({
        name: 'Demo_Statement_With_Math_Errors.pdf',
        size: 145000
      });

      setRawTransactions(
        getMockSbiTransactions()
      );

      return;
    }


    setCurrentFile({
      name: 'Demo_Statement_Clean_Verified.pdf',
      size: 98000
    });


    setRawTransactions([

      {
        id: 'c-01',
        lineNo: 1,
        date: '2026-07-02',
        description: 'OPENING BALANCE CARRIED FORWARD',
        prevBalance: 50000,
        debit: 0,
        credit: 0,
        currBalance: 50000
      },

      {
        id: 'c-02',
        lineNo: 2,
        date: '2026-07-05',
        description: 'NEFT CREDIT — MONTHLY SALARY',
        prevBalance: 50000,
        debit: 0,
        credit: 60000,
        currBalance: 110000
      },

      {
        id: 'c-03',
        lineNo: 3,
        date: '2026-07-10',
        description: 'UPI PAYMENT — RENT TRANSFER',
        prevBalance: 110000,
        debit: 25000,
        credit: 0,
        currBalance: 85000
      },

      {
        id: 'c-04',
        lineNo: 4,
        date: '2026-07-15',
        description: 'IMPS CREDIT — FREELANCE PAYMENT',
        prevBalance: 85000,
        debit: 0,
        credit: 15000,
        currBalance: 100000
      }

    ]);

  };


  // =========================================================
  // UPDATE CELL
  // =========================================================

  const handleUpdateCell = (
    rowId,
    field,
    newValue
  ) => {

    setRawTransactions((previousRows) => {

      return previousRows.map((row) => {

        if (row.id !== rowId) {
          return row;
        }

        const updatedRow = {
          ...row,
          [field]: newValue
        };

        if (
          [
            'prevBalance',
            'debit',
            'credit',
            'currBalance'
          ].includes(field)
        ) {

          updatedRow[field] =
            parseRupeeNumber(newValue);

        }

        return updatedRow;

      });

    });

  };


  // =========================================================
  // ADD ROW
  // =========================================================

  const handleAddRow = () => {

    const lastRow =
      rawTransactions[
      rawTransactions.length - 1
      ];

    const previousBalance =
      lastRow
        ? parseRupeeNumber(
          lastRow.currBalance
        )
        : 100000;

    const newRow = {

      id: `tx-${Date.now()}`,

      lineNo:
        rawTransactions.length + 1,

      date:
        new Date()
          .toISOString()
          .split('T')[0],

      description:
        'NEW MANUAL TRANSACTION ITEM',

      prevBalance:
        previousBalance,

      debit: 0,

      credit: 5000,

      currBalance:
        previousBalance + 5000

    };

    setRawTransactions((previous) => [
      ...previous,
      newRow
    ]);

  };


  // =========================================================
  // DELETE ROW
  // =========================================================

  const handleDeleteRow = (rowId) => {

    setRawTransactions((previous) =>
      previous.filter(
        (row) => row.id !== rowId
      )
    );

  };


  // =========================================================
  // RESET
  // =========================================================

  const handleResetData = () => {

    setRawTransactions(
      getMockSbiTransactions()
    );

  };


  // =========================================================
  // LOGIN SCREEN
  // =========================================================

  if (!isAuthenticated) {

    return (
      <Auth
        onLogin={handleAuthSuccess}
      />
    );

  }


  // =========================================================
  // MAIN APPLICATION
  // =========================================================

  return (

    <div
      className="
        min-h-screen
        bg-slate-100
        flex
        flex-col
        font-sans
        text-slate-900
      "
    >

      {/* HEADER */}

      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onOpenApiModal={() =>
          setIsApiModalOpen(true)
        }
      />


      {/* USER BAR */}

      <div
        className="
          bg-white
          border-b
          border-slate-200
          px-4
          py-2
          flex
          justify-end
          items-center
          gap-3
        "
      >

        {currentUser && (

          <span className="text-xs text-slate-600">

            Logged in as{' '}

            <strong className="text-slate-900">

              {currentUser.name ||
                currentUser.email ||
                'User'}

            </strong>

          </span>

        )}

        <button
          type="button"
          onClick={handleLogout}
          className="
            flex
            items-center
            gap-2
            px-3
            py-1.5
            rounded-lg
            bg-red-50
            text-red-600
            border
            border-red-200
            hover:bg-red-100
            transition
            text-xs
            font-semibold
          "
        >

          <LogOut className="w-3.5 h-3.5" />

          Logout

        </button>

      </div>


      {/* WORKSPACE */}

      <div className="flex-1 flex overflow-hidden">

        {/* SIDEBAR */}

        <Sidebar
          activeTab={activeTab}
          setActiveTab={setActiveTab}
          currentUser={currentUser}
        />

        {/* MAIN CONTENT */}

        <main
          className="
            flex-1
            p-4
            md:p-6
            overflow-y-auto
            max-w-7xl
            mx-auto
            w-full
            space-y-6
          "
        >

          {/* =================================================
              CORPORATE
          ================================================= */}

          {activeTab === 'corporate' ? (

            <CorporateOverview
              onOpenParser={() =>
                setActiveTab('parser')
              }
            />

          ) : activeTab === 'admin' ||
            activeTab === 'admin-users' ||
            activeTab === 'admin-settings' ? (

            /* =================================================
               ADMIN
            ================================================= */

            <AdminPanel
              currentUser={currentUser}
              onClose={() =>
                setActiveTab('parser')
              }
            />

          ) : (

            /* =================================================
               PARSER
            ================================================= */

            <div
              className="
                space-y-5
                animate-fade-in
              "
            >

              {/* FILE UPLOAD */}

              <FileUpload
                onFileUpload={handleFileUpload}
                isProcessing={isProcessing}
                selectedBank={selectedBank}
                setSelectedBank={setSelectedBank}
                onLoadSample={handleLoadSample}
              />


              {/* DOCUMENT + TRANSACTIONS */}

              <div
                className="
                  grid
                  grid-cols-1
                  lg:grid-cols-12
                  gap-5
                  min-h-[560px]
                "
              >

                {/* DOCUMENT VIEWER */}

                <div
                  className="
                    lg:col-span-5
                    h-[560px]
                  "
                >

                  <DocumentViewer
                    currentFile={currentFile}
                    selectedBank={selectedBank}
                    transactions={
                      validationResult.validatedRows
                    }
                  />

                </div>


                {/* TRANSACTION GRID */}

                <div
                  className="
                    lg:col-span-7
                    h-[560px]
                    flex
                    flex-col
                  "
                >

                  <TransactionGrid
                    transactions={
                      validationResult.validatedRows
                    }

                    onUpdateCell={
                      handleUpdateCell
                    }

                    onAddRow={
                      handleAddRow
                    }

                    onDeleteRow={
                      handleDeleteRow
                    }

                    onResetData={
                      handleResetData
                    }
                  />

                </div>

              </div>


              {/* VALIDATION BAR */}

              <div
                className="
                  bg-slate-900
                  text-white
                  rounded-xl
                  p-4
                  border
                  border-slate-800
                  shadow-xl
                  flex
                  flex-wrap
                  items-center
                  justify-between
                  gap-4
                  sticky
                  bottom-4
                  z-30
                "
              >

                <div
                  className="
                    flex
                    flex-wrap
                    items-center
                    gap-6
                    text-xs
                  "
                >

                  {/* DEBITS */}

                  <div>

                    <span
                      className="
                        text-slate-400
                        block
                        text-[10px]
                        uppercase
                        tracking-wider
                        font-semibold
                      "
                    >
                      Total Debits
                    </span>

                    <strong
                      className="
                        text-red-400
                        font-mono
                        text-sm
                      "
                    >
                      {formatRupee(
                        validationResult.totalDebit
                      )}
                    </strong>

                  </div>


                  <div
                    className="
                      h-6
                      w-px
                      bg-slate-800
                      hidden
                      sm:block
                    "
                  />


                  {/* CREDITS */}

                  <div>

                    <span
                      className="
                        text-slate-400
                        block
                        text-[10px]
                        uppercase
                        tracking-wider
                        font-semibold
                      "
                    >
                      Total Credits
                    </span>

                    <strong
                      className="
                        text-emerald-400
                        font-mono
                        text-sm
                      "
                    >
                      {formatRupee(
                        validationResult.totalCredit
                      )}
                    </strong>

                  </div>


                  <div
                    className="
                      h-6
                      w-px
                      bg-slate-800
                      hidden
                      sm:block
                    "
                  />


                  {/* VALIDATION */}

                  <div>

                    <span
                      className="
                        text-slate-400
                        block
                        text-[10px]
                        uppercase
                        tracking-wider
                        font-semibold
                      "
                    >
                      Verification Status
                    </span>


                    {validationResult.totalErrors > 0 ? (

                      <span
                        className="
                          inline-flex
                          items-center
                          gap-1.5
                          bg-red-950
                          text-red-300
                          font-bold
                          px-2.5
                          py-0.5
                          rounded-full
                          border
                          border-red-800
                        "
                      >

                        <AlertTriangle
                          className="
                            w-3.5
                            h-3.5
                            text-red-500
                          "
                        />

                        {validationResult.totalErrors}
                        {' '}
                        Math Error(s) Detected

                      </span>

                    ) : (

                      <span
                        className="
                          inline-flex
                          items-center
                          gap-1.5
                          bg-emerald-950
                          text-emerald-300
                          font-bold
                          px-2.5
                          py-0.5
                          rounded-full
                          border
                          border-emerald-800
                        "
                      >

                        <CheckCircle2
                          className="
                            w-3.5
                            h-3.5
                            text-emerald-400
                          "
                        />

                        100% Math Verified

                      </span>

                    )}

                  </div>

                </div>


                {/* GOOGLE SHEETS */}

                <div
                  className="
                    flex
                    items-center
                    gap-3
                  "
                >

                  {validationResult.totalErrors > 0 && (

                    <span
                      className="
                        text-[11px]
                        text-amber-300
                        hidden
                        md:block
                      "
                    >
                      💡 Click red cells to edit math & unlock sync
                    </span>

                  )}


                  <button
                    type="button"
                    onClick={() =>
                      setIsSheetsModalOpen(true)
                    }
                    disabled={
                      validationResult.totalErrors > 0
                    }
                    className={`
                      flex
                      items-center
                      gap-2
                      px-5
                      py-2.5
                      rounded-xl
                      font-extrabold
                      text-xs
                      transition
                      shadow-lg
                      ${validationResult.totalErrors > 0
                        ? 'bg-slate-800 text-slate-500 border border-slate-700 cursor-not-allowed'
                        : 'bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white'
                      }
                    `}
                  >

                    <FileSpreadsheet className="w-4 h-4" />

                    Sync to Google Sheets
                    (Service Account)

                  </button>

                </div>

              </div>

            </div>

          )}

        </main>

      </div>


      {/* =====================================================
          MODALS
      ===================================================== */}

      <GoogleSheetsModal
        isOpen={isSheetsModalOpen}
        onClose={() =>
          setIsSheetsModalOpen(false)
        }
        transactions={
          validationResult.validatedRows
        }
        errorCount={
          validationResult.totalErrors
        }
      />


      <ApiModal
        isOpen={isApiModalOpen}
        onClose={() =>
          setIsApiModalOpen(false)
        }
      />

    </div>

  );

}


export default App;