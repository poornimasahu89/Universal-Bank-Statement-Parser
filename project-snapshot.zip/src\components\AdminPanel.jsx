import React from 'react';

import {
  ShieldCheck,
  Users,
  Settings,
  ArrowLeft,
  Activity,
  Database,
  Lock,
} from 'lucide-react';

export const AdminPanel = ({
  currentUser,
  onClose,
}) => {

  return (
    <div className="space-y-6 animate-fade-in">

      {/* HEADER */}
      <div className="
        bg-slate-900
        text-white
        rounded-2xl
        p-6
        shadow-xl
      ">

        <div className="flex items-center justify-between">

          <div className="flex items-center gap-4">

            <div className="
              w-12
              h-12
              rounded-xl
              bg-purple-700
              flex
              items-center
              justify-center
            ">
              <ShieldCheck className="w-6 h-6" />
            </div>

            <div>

              <h1 className="text-xl font-bold">
                Admin Panel
              </h1>

              <p className="text-sm text-slate-400">
                Universal Bank Parser Administration
              </p>

            </div>

          </div>

          <button
            type="button"
            onClick={onClose}
            className="
              flex
              items-center
              gap-2
              px-4
              py-2
              rounded-lg
              bg-white/10
              hover:bg-white/20
              text-sm
              font-semibold
            "
          >
            <ArrowLeft className="w-4 h-4" />
            Back
          </button>

        </div>

      </div>


      {/* ADMIN USER */}
      <div className="
        bg-white
        border
        border-slate-200
        rounded-xl
        p-5
      ">

        <div className="flex items-center gap-3">

          <div className="
            w-10
            h-10
            rounded-full
            bg-purple-100
            text-purple-800
            flex
            items-center
            justify-center
            font-bold
          ">
            A
          </div>

          <div>

            <p className="text-sm font-bold text-slate-900">
              Administrator
            </p>

            <p className="text-xs text-slate-500">
              {currentUser?.email || 'Admin Account'}
            </p>

          </div>

          <span className="
            ml-auto
            px-3
            py-1
            rounded-full
            bg-emerald-100
            text-emerald-700
            text-xs
            font-bold
          ">
            ADMIN
          </span>

        </div>

      </div>


      {/* ADMIN CARDS */}
      <div className="
        grid
        grid-cols-1
        md:grid-cols-2
        lg:grid-cols-4
        gap-4
      ">

        <div className="
          bg-white
          border
          border-slate-200
          rounded-xl
          p-5
        ">
          <Activity className="w-6 h-6 text-purple-700 mb-3" />

          <p className="text-xs text-slate-500">
            System Status
          </p>

          <p className="text-lg font-bold text-emerald-600">
            Operational
          </p>
        </div>


        <div className="
          bg-white
          border
          border-slate-200
          rounded-xl
          p-5
        ">
          <Users className="w-6 h-6 text-blue-700 mb-3" />

          <p className="text-xs text-slate-500">
            Users
          </p>

          <p className="text-lg font-bold text-slate-900">
            Active
          </p>
        </div>


        <div className="
          bg-white
          border
          border-slate-200
          rounded-xl
          p-5
        ">
          <Database className="w-6 h-6 text-amber-600 mb-3" />

          <p className="text-xs text-slate-500">
            Storage Policy
          </p>

          <p className="text-lg font-bold text-slate-900">
            Zero Storage
          </p>
        </div>


        <div className="
          bg-white
          border
          border-slate-200
          rounded-xl
          p-5
        ">
          <Lock className="w-6 h-6 text-emerald-700 mb-3" />

          <p className="text-xs text-slate-500">
            Security
          </p>

          <p className="text-lg font-bold text-emerald-600">
            Protected
          </p>
        </div>

      </div>


      {/* ADMIN FUNCTIONS */}
      <div className="
        bg-white
        border
        border-slate-200
        rounded-xl
        p-6
      ">

        <h2 className="text-lg font-bold text-slate-900 mb-4">
          Administration
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">

          <button
            type="button"
            className="
              flex
              items-center
              gap-4
              p-4
              rounded-xl
              border
              border-slate-200
              hover:border-purple-300
              hover:bg-purple-50
              text-left
            "
          >

            <Users className="w-6 h-6 text-purple-700" />

            <div>

              <p className="font-semibold text-slate-900">
                User Management
              </p>

              <p className="text-xs text-slate-500">
                Manage application users
              </p>

            </div>

          </button>


          <button
            type="button"
            className="
              flex
              items-center
              gap-4
              p-4
              rounded-xl
              border
              border-slate-200
              hover:border-purple-300
              hover:bg-purple-50
              text-left
            "
          >

            <Settings className="w-6 h-6 text-purple-700" />

            <div>

              <p className="font-semibold text-slate-900">
                System Settings
              </p>

              <p className="text-xs text-slate-500">
                Configure parser and security
              </p>

            </div>

          </button>

        </div>

      </div>

    </div>
  );
};

export default AdminPanel;